import CommunityTeaser from './community-teaser';
/* eslint-disable @next/next/no-html-link-for-pages -- Vinext's Workers output keeps same-origin navigation as native links. */
const locales = [
  ['ja', '🇯🇵 日本語'], ['en', '🇺🇸 English'], ['zh', '🇹🇼 繁體中文'],
  ['ko', '🇰🇷 한국어'], ['th', '🇹🇭 ไทย'], ['id', '🇮🇩 Indonesia'], ['vi', '🇻🇳 Tiếng Việt'],
] as const;

/** Opening this compact entry must not download the interactive board first. */
export default function Home() {
  return <main className="shell">
    <nav className="topbar">
      <a className="wordmark" href="/">LR <span>COMMUNITY</span></a>
      <div className="landing-locales" aria-label="Language">
        {locales.map(([code, label]) => <a key={code} href={`/boards?lang=${code}`}>{label}</a>)}
      </div>
    </nav>
    <header className="intro">
      <p className="eyebrow">UNOFFICIAL STATISTICS</p>
      <h1>LINEレンジャー<br />レジェンド帯キャラ集計</h1>
      <p>レジェンド帯プレイヤーの防衛チームから、キャラクターの編成数と採用率を集計しています。</p>
      <p className="tap-hint">キャラクターをタップすると、装備ランキングが見れます。</p>
    </header>
    <section className="entry" aria-labelledby="community-title">
      <div className="entry-heading"><span className="entry-icon" aria-hidden="true">💬</span><h2 id="community-title">新キャラ情報掲示板</h2></div>
      <p>投票・コメント・動画で、新キャラについて話そう！</p>
      <CommunityTeaser/>
      <div className="entry-actions">
        <a className="entry-button primary" href="/boards">掲示板を開く <span aria-hidden="true">↗</span></a>
        <a className="entry-button secondary" href="#ranking">集計表へ <span aria-hidden="true">↓</span></a>
      </div>
    </section>
    <section id="ranking" className="ranking-link">
      <h2>集計表へ</h2>
      <p>評価用の掲示板は、本番の集計や利用者には影響しません。</p>
      <a className="primary-link" href="https://line-rangers-fan.github.io/line-rangers-pvp/#ranking-section" target="_blank" rel="noopener noreferrer">PvP集計表を開く <span aria-hidden="true">↗</span></a>
    </section>
  </main>;
}
